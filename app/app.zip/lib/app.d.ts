import type { Application } from './declarations';
declare const app: Application;
export { app };
