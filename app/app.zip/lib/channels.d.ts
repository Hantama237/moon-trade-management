import '@feathersjs/transport-commons';
import type { Application } from './declarations';
export declare const channels: (app: Application) => void;
