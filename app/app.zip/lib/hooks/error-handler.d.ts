import type { HookContext } from '../declarations';
export declare const featherErrorHandler: (context: HookContext) => Promise<HookContext | undefined>;
