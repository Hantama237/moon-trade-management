import type { HookContext, NextFunction } from '../declarations';
export declare const logError: (context: HookContext, next: NextFunction) => Promise<void>;
