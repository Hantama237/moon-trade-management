import type { HookContext, NextFunction } from '../declarations';
export declare const logRuntime: (context: HookContext, next: NextFunction) => Promise<void>;
