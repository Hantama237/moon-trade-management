export declare const logger: import("winston").Logger;
