import type { Application } from '../declarations';
export declare const services: (app: Application) => void;
