import { Ajv } from '@feathersjs/schema';
export declare const dataValidator: Ajv;
export declare const queryValidator: Ajv;
